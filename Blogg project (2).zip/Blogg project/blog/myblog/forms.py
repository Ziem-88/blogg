from django import forms
from django.contrib.auth.models import User 
from django.forms import widgets
from myblog.models import CategoryModel, PostModel, OrderModel
from django.contrib.auth.forms import UserCreationForm

class postForm(forms.ModelForm): 
    class Meta:
        model = PostModel 
        fields = "__all__"
    
class orderForm(forms.ModelForm):
    class Meta:
        model = OrderModel
        fields = ['name','email','phone','address']


class RegisterForm(UserCreationForm):
    class Meta:
        model=User
        fields = ['username','email','password1','password2'] 