from django.shortcuts import render , redirect
from myblog.models import PostModel , CommentModel, CategoryModel, OrderModel
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from datetime import datetime
from django.db.models import Q
from django.contrib import messages
from django.core.paginator import Paginator
from myblog.forms import postForm, orderForm
import random
import string
from .forms import RegisterForm

def generate_order_number(length=8):
    characters = string.ascii_uppercase + string.digits
    order_number = ''.join(random.choice(characters) for _ in range(length))
    return order_number

order_number = generate_order_number()

# Create your views here.
def bloglist(request):
    posts = PostModel.objects.all().order_by('-created_at')
    paginator = Paginator(posts, 4)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    orders = OrderModel.objects.filter(author_id = request.user.id)
    return render(request, "bloglist.html", {"posts":page_obj,"orders":orders})

@permission_required('myblog.add_postmodel', login_url='login')
def blogcreate(request):
    if request.method == "GET":
        form = postForm()
        return render(request, "blogcreate.html",{"form":form})
    
    if request.method == "POST":
        form = postForm(request.POST,request.FILES) 
        if form.is_valid():
            form.save()
            messages.success(request, "The post has been created successfully.")
            return redirect('/blog/list/')
        else: 
            messages.error(request, "Somethine wrong !")
            return redirect('/blog/list/')
    
@permission_required('myblog.view_postmodel', login_url='login')
def blogdetail(request, post_id):
    posts = PostModel.objects.get(id=post_id)
    users = User.objects.get(id=posts.author_id)
    comments = CommentModel.objects.filter(post_id=post_id)
    return render(request, "blogdetail.html", {"posts":posts,"users":users,"comments":comments})

@permission_required('myblog.delete_postmodel', login_url='login')
def blogdelete(request, post_id):
    posts = PostModel.objects.filter(id=post_id)
    posts.delete()
    messages.error(request, "The post has been deleted successfully.")
    return redirect('/blog/list/')

@permission_required('myblog.change_postmodel', login_url='login')
def blogupdate(request, post_id):
    if request.method == "GET":
        categorys = CategoryModel.objects.all()
        posts = PostModel.objects.get(id=post_id)
        users = User.objects.all()
        posts.created_at = posts.created_at.strftime('%Y-%m-%dT%H:%M')
        return render(request, "blogupdate.html", {"posts":posts, "categorys":categorys, "users":users})
    
    if request.method == "POST":
        posts = PostModel.objects.get(id = post_id)
        posts.title = request.POST.get('title')
        posts.body = request.POST.get('body')
        posts.category_id = request.POST.get('category')
        if request.FILES.get('image'):
            posts.image = request.FILES.get('image')
        posts.save()
        messages.success(request, "The post has been updated successfully.")
        return redirect("/blog/list/")
    
@permission_required('myblog.add_commentmodel', login_url='login')
def cmt_create(request, post_id):
    if request.method == "POST":
        comment = CommentModel.objects.create(
            content = request.POST.get('content'),
            author_id = request.user.id,
            post_id = post_id
        )
        comment.save()
        return redirect('/blog/detail/' + str(post_id) + '/')
    
@permission_required('myblog.delete_commentmodel', login_url='login')
def cmt_delete(request, cmt_id, post_id):
    comment = CommentModel.objects.filter(id=cmt_id)
    comment.delete()
    return redirect('/blog/detail/' + str(post_id) + '/')

def cmt_update(request, cmt_id, post_id):
    if request.method == "GET":
        comment = CommentModel.objects.get(id=cmt_id)
        author = User.objects.all()
        text = {"comment":comment, "author":author, "post":post_id}
        return render(request,"cmtupdate.html",text)
    if request.method == "POST":
        comment = CommentModel.objects.get(id=cmt_id)
        comment.content = request.POST.get('content')
        comment.author_id = request.POST.get('author')
        comment.save()
        return redirect('/blog/detail/' + str(post_id) + '/')

def login_view(request):
    if request.method == "GET":
        return render(request, 'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username,password=password)
        if user is not None:
            login(request, user)
            return redirect('/blog/list/')
        else:
            return redirect('/login/')
        
def logout_view(request): 
    logout(request)
    return redirect('/login/')

def search_by(request):
    search = request.GET.get('search') 
    if search:
        posts = PostModel.objects.filter( 
            Q(title__icontains=search) | 
            Q(body__icontains=search)
        )
        return render(request, 'bloglist.html', {'posts': posts}) 
    else:
        posts = PostModel.objects.all().order_by('-created_at') 
        return render(request, 'bloglist.html', {'posts': posts})

def order_create(request, post_id):
    if request.method == "GET":
        post = PostModel.objects.get(id=post_id)
        form = orderForm(instance=post)
        return render(request, 'ordercreate.html', {'form': form})

    if request.method == "POST":
        form = postForm(request.POST,request.FILES) 
        order = OrderModel.objects.create(
            post_id = post_id,
            order_no = order_number,
            name = request.POST.get('name'),
            email = request.POST.get('email'),
            address = request.POST.get('address'),
            phone = request.POST.get('phone'),
            datetime = datetime.now(),
            author_id = request.user.id,
            status = "open"
        )
        order.save()
        messages.success(request, "The Order has been created successfully.")
        return redirect('/blog/list/')
    
def order_delete(request, order_id):
    order = OrderModel.objects.get(id=order_id)
    order.delete()
    return redirect('/blog/list/')

def order_detail(request, order_id):
    order = OrderModel.objects.get(id=order_id)
    return render(request, 'orderdetail.html', {"order":order})


def sign_up(request):
    if request.method == 'GET':
        form = RegisterForm()
        return render(request, 'register.html', { 'form': form})
    if request.method == 'POST':
        form = RegisterForm(request.POST) 
        if form.is_valid():
            user = form.save(commit=False)
            user.username = user.username.lower()
            user.save()
            messages.success(request, 'You have singed up successfully.')
            login(request, user)
            return redirect('/blog/list/')
        else:
            return render(request, 'register.html', {'form': form})