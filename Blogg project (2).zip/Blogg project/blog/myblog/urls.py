from django.urls import path
from myblog import views 

from django.contrib.auth.views import (
    PasswordResetView, 
    PasswordResetDoneView, 
    PasswordResetConfirmView,
    PasswordResetCompleteView
)

urlpatterns = [
    path('list/', views.bloglist, name="bloglist"),
    path('create/', views.blogcreate),
    path('detail/<int:post_id>/', views.blogdetail),
    path('delete/<int:post_id>/', views.blogdelete),
    path('update/<int:post_id>/', views.blogupdate),

    path('cmt/create/<int:post_id>/',views.cmt_create),
    path('cmt/delete/<int:cmt_id>/<int:post_id>/',views.cmt_delete),
    path('cmt/update/<int:cmt_id>/<int:post_id>/',views.cmt_update, name="cmt_update"),

    path('search_by/', views.search_by),
    path('order/create/<int:post_id>/', views.order_create),
    path('order/delete/<int:order_id>/', views.order_delete),
    path('order/detail/<int:order_id>/', views.order_detail),

    
    path('register/', views.sign_up, name='register'),

    path('password-reset/', PasswordResetView.as_view(template_name='password_reset.html'),name='password-reset'),
    path('password-reset/done/', PasswordResetDoneView.as_view(template_name='password_reset_done.html'),name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html'),name='password_reset_confirm'),
    path('password-reset-complete/',PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'),name='password_reset_complete'),
]
