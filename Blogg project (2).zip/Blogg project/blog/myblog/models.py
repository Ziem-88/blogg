from django.db import models
from datetime import datetime
from django.contrib.auth.models import User

class CategoryModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)    

    def __str__(self):
        return self.name

class PostModel(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)
    body = models.TextField()
    image = models.ImageField(default=None, blank=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    category = models.ForeignKey(CategoryModel, on_delete=models.CASCADE, default=None)
    created_at = models.DateTimeField(default=datetime.now)

class CommentModel(models.Model):
    id = models.AutoField(primary_key=True)
    content = models.CharField(max_length=100)
    author = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    post = models.ForeignKey(PostModel, on_delete=models.CASCADE, default=None)

class UserDetailModel(models.Model):
    id = models.AutoField(primary_key=True)
    address = models.TextField()
    phone = models.IntegerField()
    birthday = models.DateField()
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=None)
    def __str__(self):
        return self.user
class CategoryDetailModel(models.Model):
    id = models.AutoField(primary_key=True)
    description = models.TextField()
    category = models.ManyToManyField(CategoryModel)
    def __str__(self):
        return self.description
    
ORDER_CHOICES = (
    ("open","Open"),
    ("confirmed","Confirmed"),
    ("completed","Completed"),
    ("canelled","Cancelled")
)

class OrderModel(models.Model):
    id = models.AutoField(primary_key=True)
    post = models.ForeignKey(PostModel, on_delete=models.CASCADE, default=None)
    order_no = models.CharField(max_length=20)
    name = models.CharField(max_length=20)
    email = models.EmailField()
    address = models.TextField()
    phone = models.IntegerField(default=None)
    author = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    datetime = models.DateTimeField(default=datetime.now)
    status = models.TextField(choices = ORDER_CHOICES)